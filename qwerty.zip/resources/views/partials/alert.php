<div id = "modal_alert" class="modal" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h2 id = "tituloMensaje" class="modal-title"></h2>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p id = "mensaje1"> </p>
        <p id = "mensaje2"> </p>
      </div>
      <div class="modal-footer">
        <button type="button" data-dismiss="modal"  class="btn btn-info">Aceptar</button>
       </div>
    </div>
  </div>
</div>

