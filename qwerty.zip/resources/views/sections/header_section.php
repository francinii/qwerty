<div class="row"> 
    <div id = "portada_section_expandida" class="col-md-12 frame frame_header" style="padding: 0% 0% 2% 0%">
       <img src="<?=$routes["img_layout_frame_1"]?>" alt = "">
    </div>
    <div id = "portada_section_reducida" class="col-md-12 frame frame_header" style="padding: 0% 0% 2% 0%">
       <img src="<?=$routes["img_layout_frame_7"]?>" alt = "">
    </div>
</div>