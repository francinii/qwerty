
<link href="<?= $routes["librerias_bootstrap"] ?>" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" href="<?=$routes["link_normalize"]?>" >
<link rel='stylesheet' href='<?= $routes["link_bootstrap"]?>'>
<link rel="stylesheet" href="<?= $routes["css_main"]?>" type="text/css"/>
<link rel="icon" type="image/ico" href="<?= $routes["img_content_favicon"] ?>">
<link href="<?= $routes["css_timeline"]?>" rel="stylesheet" type="text/css"/>

<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
<meta name="descripcion" content="<?= $vocab["keyword_1"] ?>"/>	
<meta name="keywords" content="<?= $vocab["keyword_2"] ?>"/>
<meta name="keywords" content="<?= $vocab["keyword_3"] ?>"/>
<meta name="keywords" content="<?= $vocab["keyword_4"] ?>"/>
<meta name="keywords" content="<?= $vocab["keyword_5"] ?>"/>
<meta name="keywords" content="<?= $vocab["keyword_6"] ?>"/>
<meta name="keywords" content="<?= $vocab["keyword_7"] ?>"/>
